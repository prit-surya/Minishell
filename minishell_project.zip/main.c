/*****************
Name : Pritesh suryawanshi
Date : 15/11/2024
Description : Minishell project
Sample input : ./a.out
Sample output :
******************/
#include "main.h"

int main()
{
    //clear the screen
    system("clear");
    
    //varible declaration
    //array to store the input
    char input_string[25];
    
    //array to store the prompt
    char prompt[25] = "msh";

    //scan the input
    scan_input(prompt, input_string);

    return 0;
}
